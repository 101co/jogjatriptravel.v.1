<?php

namespace App\Livewire;

use Livewire\Component;

class TourismCatalogue extends Component
{
    public function render()
    {
        return view('livewire.tourism-catalogue');
    }
}
