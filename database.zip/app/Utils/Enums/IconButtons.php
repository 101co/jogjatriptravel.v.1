<?php
namespace App\Utils\Enums;

enum IconButtons: string
{
  case ADD = 'heroicon-c-plus-circle';
  case CHECK = 'heroicon-c-check';
}